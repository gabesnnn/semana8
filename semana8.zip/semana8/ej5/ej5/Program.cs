﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese la nota: ");

            double nota = double.Parse(Console.ReadLine());

            // Validar nota
            if (EsNotaValida(nota))
            {
                string clasificacion = ClasificarNota(nota);

                MostrarReporte(nota, clasificacion);
            }

            else
            {
                Console.WriteLine("Error: la nota debe estar entre 0 y 20.");
            }

            Console.ReadKey();
        }

        // Función para validar
        static bool EsNotaValida(double nota)
        {
            return nota >= 0 && nota <= 20;
        }

        // Función para clasificar
        static string ClasificarNota(double nota)
        {
            if (nota >= 18)
            {
                return "Excelente";
            }

            else if (nota >= 14)
            {
                return "Bueno";
            }

            else if (nota >= 11)
            {
                return "Regular";
            }

            else
            {
                return "Desaprobado";
            }
        }

        // Método void
        static void MostrarReporte(double nota, string clasificacion)
        {
            Console.WriteLine("\n=== REPORTE ===");

            Console.WriteLine($"Nota ingresada: {nota:F2}");

            Console.WriteLine($"Clasificación: {clasificacion}");
        }
    }
}
